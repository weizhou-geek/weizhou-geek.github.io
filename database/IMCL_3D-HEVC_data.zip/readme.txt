Firstly, thank you for your interest in our 3D-HEVC bitstream PhaseI database.



If you use this database, we kindly ask you to reference the following paper:
Zhou W, Liao N, Chen Z, et al.: " 3D-HEVC visual quality assessment: Database and bitstream model", 2016 Eighth International Conference on Quality of Multimedia Experience (QoMEX).

You can use the "TAppDecoder.exe" to decode the 3D-HEVC bitstreams to get the distorted videos, like the following command: 
TAppDecoder.exe -b filename.bit -o filename.yuv



If you have any questions about the database, please contact weichou@mail.ustc.edu.cn.
Thank you!